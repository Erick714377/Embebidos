/*
 * Copyright 2016-2022 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file    Examen1_practico.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MK66F18.h"
#include "fsl_debug_console.h"
/* TODO: insert other include files here. */

/* TODO: insert other definitions and declarations here. */

/*
 * @brief   Application entry point.
 */
#define FOREVER_AND_EVER 1U
 void vTask1 (void *pvParameters);
 void vTask2 (void *pvParameters);
void vPrintTask3 (void *pvParameters);
void vTaskInitAll( void *pvParameters );

SemaphoreHandle_t task1_semaphore;
SemaphoreHandle_t task2_semaphore;

EventGroupHandle_t xEventGroup;
/*The Queue to send the time */
QueueHandle_t xTimeQueue;


typedef enum{
	T1, T2
}ID_t;
typedef struct{
	const uint8_t Tarea_1;
	const uint8_t Tarea_2;
}task_t;
typedef struct{
	uint8_t string;
	ID_t id;
}task_strct_t;
int main(void) {

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif
    uart_config_t config;
    uint32_t uart_clock;



    	xTimeQueue= xQueueCreate(1, sizeof(Mensaje));


    	xMutex = xSemaphoreCreateMutex();

    	Event_Group = xEventGroupCreate();
    	 UART_GetDefaultConfig(&config);
    	    	config.baudRate_Bps = UART_BAUDRATE;
    	    	config.enableTx     = 1;
    	    	config.enableRx     = 1;
    	    	uart_clock = CLOCK_GetFreq(UART0_CLK_SRC);
    	    	UART_Init(UART0, &config, uart_clock);

        xTaskCreate( vTaskInitAll, "Task Init All", 1000, NULL, 4, NULL );

    	vTaskStartScheduler();


    /* Force the counter to be placed into memory. */
    volatile static int i = 0 ;
    /* Enter an infinite loop, just incrementing a counter. */
    while(1) {
        i++ ;
        /* 'Dummy' NOP to allow source level single stepping of
            tight while() loop */
        __asm volatile ("nop");
    }
    return 0 ;
}


void vTask1( void *pvParameters )
{
	task_strct_t string_1 = "Soy la tarea 1\n";
	task_strct_t* pxSeconds = &string_1;


	TickType_t xLastWakeTime;

	while(FOREVER_AND_EVER)
		{
			/*Delay until 1 sec is reached*/
			vTaskDelayUntil(&xLastWakeTime,xDelay1s);
			xLastWakeTime = xTaskGetTickCount();


			xSemaphoreGive(task1_semaphore);

			/*If seconds is equal to alarm.seconds, set the bit of the Group*/
			/*Send seconds to the Queue*/
			xQueueSend( xTimeQueue, ( void * ) &string_1, portMAX_DELAY);
		}
}

void vTask2( void *pvParameters )
{
	task_strct_t string_2 = "Tarea 2 en ejecucion\n";
	task_strct_t* pxSeconds = &string_2;

	TickType_t xLastWakeTime;
	xSemaphoreTake(task1_semaphore,portMAX_DELAY);

	while(FOREVER_AND_EVER)
		{
			/*Delay until 1 sec is reached*/
			vTaskDelayUntil(&xLastWakeTime,xDelay1s);
			xLastWakeTime = xTaskGetTickCount();


			xSemaphoreGive(task2_semaphore);

			/*If seconds is equal to alarm.seconds, set the bit of the Group*/
			/*Send seconds to the Queue*/
			xQueueSend( xTimeQueue, ( void * ) &string_2, portMAX_DELAY);
		}
}
void vPrintTask3 (void *pvParameters){
	task_strct_t* pxQueueDataRcvd;
	while(FOREVER_AND_EVER)
		{
			if( xQueueReceive( xTimeQueue, &( pxQueueDataRcvd ), portMAX_DELAY ) )
			{
				switch(pxQueueDataRcvd->id)
							{
								case T1:
									PRINTF("%s",pxQueueDataRcvd->string );
									break;
								case T2:
									PRINTF("%s",pxQueueDataRcvd->string );
									break;
								default:
									break;
							}
			}
		}

}
void vTaskInitAll( void *pvParameters ){
	xTaskCreate(
	                 vTask1,     /* Pointer to the function that implements the task. */
	                 "Task 1",	/* Text name for the task.  This is to facilitate debugging only. */
	         		1000,		/* Stack depth - most small microcontrollers will use much less stack than this. */
	         		NULL,		/* We are not using the task parameter. */
	         		3,			/* This task will run at priority 1. */
	         		NULL );		/* We are not using the task handle. */

	         	/* Create the other task in exactly the same way. */
	xTaskCreate( vTask2, "Task 2", 1000, NULL, 3, NULL );
	xTaskCreate( vPrintTask3, "Task 3", 1000, NULL, 3, NULL );
	vTaskSuspend(NULL);
}

