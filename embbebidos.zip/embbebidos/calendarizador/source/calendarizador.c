#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MK66F18.h"
#include "fsl_debug_console.h"
volatile uint32_t g_systickCounter = 0;

void SysTick_DelayTicks(uint32_t n);
void SysTick_Handler(void);
void Task(uint32_t param);

struct calendarizador {
	priority;
	period;
	state;

};
int main(void) {
	uint8_t var = 0;
	void (*pfunct[4])(uint32_t) = {Task,Task,Task,Task,Task};

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif
    SysTick_Config(SystemCoreClock / 1000U);
    PRINTF("Hello World\n");

    /* Force the counter to be placed into memory. */
    volatile static int i = 0 ;
    /* Enter an infinite loop, just incrementing a counter. */
    while(1) {
    //	SysTick_DelayTicks(1000);
    	pfunct[var](var);

		if (g_systickCounter == 0U)
		{
			g_systickCounter = 1000;
	    	var++;
	    	if(var > 3){
	    		var = 0;
	    	}
		}
    }
    return 0 ;
}
void SysTick_DelayTicks(uint32_t n)
{
    g_systickCounter = n;

}
void SysTick_Handler(void)
{
    if (g_systickCounter != 0U)
    {
        g_systickCounter--;
    }
}


void Task(uint32_t param){
	PRINTF("Task %d\n\r",param);
}
